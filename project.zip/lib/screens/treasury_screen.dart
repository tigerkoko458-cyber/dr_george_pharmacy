import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/treasury_provider.dart';
import '../utils/formatters.dart';
import '../utils/app_theme.dart';
import '../utils/pdf_exporter.dart';

class TreasuryScreen extends StatefulWidget {
  const TreasuryScreen({super.key});

  @override
  State<TreasuryScreen> createState() => _TreasuryScreenState();
}

class _TreasuryScreenState extends State<TreasuryScreen> {
  String _fromDate = Formatters.date(DateTime.now().subtract(const Duration(days: 30)));
  String _toDate = Formatters.today();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    await context.read<TreasuryProvider>().loadMovements(fromDate: _fromDate, toDate: _toDate);
  }

  @override
  Widget build(BuildContext context) {
    final treasury = context.watch<TreasuryProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('الخزينة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: () async {
              final rows = treasury.movements
                  .map((m) => [
                        Formatters.displayDate(m.movementDate),
                        m.movementType == 'in' ? 'وارد' : 'منصرف',
                        m.source,
                        Formatters.money(m.amount),
                        Formatters.money(m.balanceAfter ?? 0),
                      ])
                  .toList();
              final bytes = await PdfExporter.buildTableReport(
                title: 'كشف حركة الخزينة',
                headers: ['التاريخ', 'النوع', 'المصدر', 'المبلغ', 'الرصيد بعد الحركة'],
                rows: rows,
                footerNote: 'الرصيد الحالي: ${Formatters.money(treasury.currentBalance)}',
              );
              await PdfExporter.printOrShare(bytes, 'كشف_الخزينة.pdf');
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: AppColors.navy,
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const Text('الرصيد الحالي', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 6),
                Text(Formatters.money(treasury.currentBalance), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
              ],
            ),
          ),
          Expanded(
            child: treasury.movements.isEmpty
                ? const Center(child: Text('لا توجد حركات في هذه الفترة'))
                : ListView.separated(
                    padding: const EdgeInsets.all(12),
                    itemCount: treasury.movements.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, i) {
                      final m = treasury.movements[treasury.movements.length - 1 - i];
                      final isIn = m.movementType == 'in';
                      return ListTile(
                        leading: Icon(isIn ? Icons.arrow_downward : Icons.arrow_upward, color: isIn ? AppColors.green : Colors.red),
                        title: Text(m.description ?? _sourceLabel(m.source)),
                        subtitle: Text(Formatters.displayDate(m.movementDate)),
                        trailing: Text(
                          '${isIn ? '+' : '-'}${Formatters.money(m.amount)}',
                          style: TextStyle(color: isIn ? AppColors.green : Colors.red, fontWeight: FontWeight.bold),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _sourceLabel(String s) {
    switch (s) {
      case 'shift':
        return 'مبيعات شيفت';
      case 'collection':
        return 'تحصيل من شركة';
      case 'expense':
        return 'مصروف';
      default:
        return 'حركة يدوية';
    }
  }
}
