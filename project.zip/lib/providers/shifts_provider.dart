import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/shift.dart';
import 'treasury_provider.dart';

class ShiftsProvider extends ChangeNotifier {
  List<Shift> _shifts = [];
  List<Shift> get shifts => _shifts;

  final TreasuryProvider treasuryProvider;
  ShiftsProvider(this.treasuryProvider);

  Future<void> loadShiftsByDate(String date) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('shifts', where: 'shift_date = ?', whereArgs: [date], orderBy: 'shift_number ASC');
    _shifts = rows.map((e) => Shift.fromMap(e)).toList();
    notifyListeners();
  }

  /// إنشاء أو تحديث شيفت (شيفت واحد فقط لكل رقم شيفت في اليوم - القيد UNIQUE في قاعدة البيانات يمنع التكرار)
  Future<String?> saveShift(Shift shift) async {
    final db = await DBHelper.instance.database;
    final existing = await db.query(
      'shifts',
      where: 'shift_date = ? AND shift_number = ?',
      whereArgs: [shift.shiftDate, shift.shiftNumber],
    );

    if (existing.isNotEmpty) {
      final existingShift = Shift.fromMap(existing.first);
      if (existingShift.isClosed) {
        return 'هذا الشيفت مقفول بالفعل ولا يمكن تعديله';
      }
      await db.update('shifts', shift.toMap(), where: 'id = ?', whereArgs: [existingShift.id]);
    } else {
      await db.insert('shifts', shift.toMap());
    }
    await loadShiftsByDate(shift.shiftDate);
    return null;
  }

  /// إقفال الشيفت وترحيل النقدية إلى الخزينة
  Future<void> closeShift(int shiftId) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('shifts', where: 'id = ?', whereArgs: [shiftId]);
    if (rows.isEmpty) return;
    final shift = Shift.fromMap(rows.first);
    if (shift.isClosed) return;

    final closingBalance = shift.openingBalance + shift.cashSales;

    await db.update(
      'shifts',
      {
        'is_closed': 1,
        'closing_balance': closingBalance,
        'closed_at': DateTime.now().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [shiftId],
    );

    // ترحيل صافي المبيعات النقدية إلى الخزينة
    await treasuryProvider.recordMovement(
      date: shift.shiftDate,
      type: 'in',
      source: 'shift',
      referenceId: shift.id,
      amount: shift.cashSales,
      description: 'مبيعات نقدية - شيفت رقم ${shift.shiftNumber}',
      userId: shift.userId,
    );

    await loadShiftsByDate(shift.shiftDate);
  }

  Future<Map<String, double>> totalsForDate(String date) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('shifts', where: 'shift_date = ?', whereArgs: [date]);
    double cash = 0, visa = 0, companies = 0, other = 0;
    for (final r in rows) {
      cash += (r['cash_sales'] as num).toDouble();
      visa += (r['visa_sales'] as num).toDouble();
      companies += (r['companies_sales'] as num).toDouble();
      other += (r['other_sales'] as num).toDouble();
    }
    return {
      'cash': cash,
      'visa': visa,
      'companies': companies,
      'other': other,
      'total': cash + visa + companies + other,
    };
  }
}
