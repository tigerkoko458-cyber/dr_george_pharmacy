import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import '../db/db_helper.dart';

/// نسخ احتياطي / استرجاع لقاعدة بيانات الصيدلية
class BackupHelper {
  /// إنشاء نسخة احتياطية ومشاركتها (لحفظها على جهاز آخر / تخزين سحابي)
  static Future<File> createBackup() async {
    final dir = await getApplicationDocumentsDirectory();
    final timestamp = DateFormat('yyyy-MM-dd_HH-mm').format(DateTime.now());
    final backupPath = '${dir.path}/backup_dr_george_$timestamp.db';
    return DBHelper.instance.backupTo(backupPath);
  }

  static Future<void> shareBackup(File backupFile) async {
    await Share.shareXFiles([XFile(backupFile.path)], text: 'نسخة احتياطية - صيدلية د/ جورج مجدي');
  }

  /// اختيار ملف نسخة احتياطية من الجهاز واستعادته (يستبدل البيانات الحالية بالكامل)
  static Future<bool> pickAndRestore() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['db'],
    );
    if (result == null || result.files.single.path == null) return false;
    await DBHelper.instance.restoreFrom(result.files.single.path!);
    return true;
  }
}
