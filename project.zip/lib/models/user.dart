class AppUser {
  final int? id;
  final String username;
  final String passwordHash;
  final String fullName;
  final String role; // admin | manager | employee
  final bool canManageCompanies;
  final bool canManageExpenses;
  final bool canViewTreasury;
  final bool canCloseDay;
  final bool canViewReports;
  final bool canManageUsers;
  final bool isActive;
  final String createdAt;

  AppUser({
    this.id,
    required this.username,
    required this.passwordHash,
    required this.fullName,
    this.role = 'employee',
    this.canManageCompanies = false,
    this.canManageExpenses = false,
    this.canViewTreasury = false,
    this.canCloseDay = false,
    this.canViewReports = false,
    this.canManageUsers = false,
    this.isActive = true,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'username': username,
      'password_hash': passwordHash,
      'full_name': fullName,
      'role': role,
      'can_manage_companies': canManageCompanies ? 1 : 0,
      'can_manage_expenses': canManageExpenses ? 1 : 0,
      'can_view_treasury': canViewTreasury ? 1 : 0,
      'can_close_day': canCloseDay ? 1 : 0,
      'can_view_reports': canViewReports ? 1 : 0,
      'can_manage_users': canManageUsers ? 1 : 0,
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt,
    };
  }

  factory AppUser.fromMap(Map<String, dynamic> map) {
    return AppUser(
      id: map['id'] as int?,
      username: map['username'] as String,
      passwordHash: map['password_hash'] as String,
      fullName: map['full_name'] as String,
      role: map['role'] as String,
      canManageCompanies: (map['can_manage_companies'] as int) == 1,
      canManageExpenses: (map['can_manage_expenses'] as int) == 1,
      canViewTreasury: (map['can_view_treasury'] as int) == 1,
      canCloseDay: (map['can_close_day'] as int) == 1,
      canViewReports: (map['can_view_reports'] as int) == 1,
      canManageUsers: (map['can_manage_users'] as int) == 1,
      isActive: (map['is_active'] as int) == 1,
      createdAt: map['created_at'] as String,
    );
  }
}
