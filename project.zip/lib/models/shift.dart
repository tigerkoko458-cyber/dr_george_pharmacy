class Shift {
  final int? id;
  final String shiftDate; // yyyy-MM-dd
  final int shiftNumber; // 1, 2, 3
  final int userId;
  final double openingBalance;
  final double cashSales;
  final double visaSales;
  final double companiesSales;
  final double otherSales;
  final double? closingBalance;
  final String? notes;
  final bool isClosed;
  final String? closedAt;
  final String createdAt;

  Shift({
    this.id,
    required this.shiftDate,
    required this.shiftNumber,
    required this.userId,
    this.openingBalance = 0,
    this.cashSales = 0,
    this.visaSales = 0,
    this.companiesSales = 0,
    this.otherSales = 0,
    this.closingBalance,
    this.notes,
    this.isClosed = false,
    this.closedAt,
    required this.createdAt,
  });

  double get totalSales => cashSales + visaSales + companiesSales + otherSales;

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'shift_date': shiftDate,
      'shift_number': shiftNumber,
      'user_id': userId,
      'opening_balance': openingBalance,
      'cash_sales': cashSales,
      'visa_sales': visaSales,
      'companies_sales': companiesSales,
      'other_sales': otherSales,
      'closing_balance': closingBalance,
      'notes': notes,
      'is_closed': isClosed ? 1 : 0,
      'closed_at': closedAt,
      'created_at': createdAt,
    };
  }

  factory Shift.fromMap(Map<String, dynamic> map) {
    return Shift(
      id: map['id'] as int?,
      shiftDate: map['shift_date'] as String,
      shiftNumber: map['shift_number'] as int,
      userId: map['user_id'] as int,
      openingBalance: (map['opening_balance'] as num).toDouble(),
      cashSales: (map['cash_sales'] as num).toDouble(),
      visaSales: (map['visa_sales'] as num).toDouble(),
      companiesSales: (map['companies_sales'] as num).toDouble(),
      otherSales: (map['other_sales'] as num).toDouble(),
      closingBalance: (map['closing_balance'] as num?)?.toDouble(),
      notes: map['notes'] as String?,
      isClosed: (map['is_closed'] as int) == 1,
      closedAt: map['closed_at'] as String?,
      createdAt: map['created_at'] as String,
    );
  }
}
