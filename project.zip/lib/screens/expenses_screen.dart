import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/expenses_provider.dart';
import '../providers/auth_provider.dart';
import '../models/expense.dart';
import '../utils/formatters.dart';

class ExpensesScreen extends StatefulWidget {
  const ExpensesScreen({super.key});

  @override
  State<ExpensesScreen> createState() => _ExpensesScreenState();
}

class _ExpensesScreenState extends State<ExpensesScreen> {
  final _categoryCtrl = TextEditingController();
  final _descCtrl = TextEditingController();
  final _amountCtrl = TextEditingController();
  String _date = Formatters.today();

  static const _commonCategories = ['إيجار', 'كهرباء ومياه', 'صيانة', 'رواتب', 'نقل وانتقالات', 'أخرى'];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<ExpensesProvider>().loadExpenses());
  }

  @override
  Widget build(BuildContext context) {
    final expenses = context.watch<ExpensesProvider>().expenses;
    final total = expenses.fold<double>(0, (s, e) => s + e.amount);

    return Scaffold(
      appBar: AppBar(title: const Text('المصروفات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Autocomplete<String>(
            optionsBuilder: (textEditingValue) {
              if (textEditingValue.text.isEmpty) return _commonCategories;
              return _commonCategories.where((c) => c.contains(textEditingValue.text));
            },
            onSelected: (v) => _categoryCtrl.text = v,
            fieldViewBuilder: (context, controller, focusNode, onSubmit) {
              controller.text = _categoryCtrl.text;
              return TextField(
                controller: controller,
                focusNode: focusNode,
                textAlign: TextAlign.right,
                decoration: const InputDecoration(labelText: 'نوع المصروف'),
                onChanged: (v) => _categoryCtrl.text = v,
              );
            },
          ),
          const SizedBox(height: 10),
          TextField(controller: _descCtrl, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'وصف (اختياري)')),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('التاريخ: ${Formatters.displayDate(_date)}'),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_date), firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => _date = Formatters.date(picked));
            },
          ),
          TextField(
            controller: _amountCtrl,
            textAlign: TextAlign.right,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'المبلغ'),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () async {
              final amount = double.tryParse(_amountCtrl.text.trim());
              if (_categoryCtrl.text.trim().isEmpty || amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى إدخال نوع المصروف والمبلغ بشكل صحيح')));
                return;
              }
              final auth = context.read<AuthProvider>();
              final expense = Expense(
                expenseDate: _date,
                category: _categoryCtrl.text.trim(),
                description: _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
                amount: amount,
                userId: auth.currentUser?.id,
                createdAt: DateTime.now().toIso8601String(),
              );
              await context.read<ExpensesProvider>().addExpense(expense);
              _categoryCtrl.clear();
              _descCtrl.clear();
              _amountCtrl.clear();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل المصروف وخصمه من الخزينة')));
              }
            },
            child: const Text('حفظ المصروف'),
          ),
          const Divider(height: 32),
          Text('إجمالي المصروفات المعروضة: ${Formatters.money(total)}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...expenses.map((e) => Card(
                child: ListTile(
                  title: Text('${e.category} - ${Formatters.money(e.amount)}'),
                  subtitle: Text('${Formatters.displayDate(e.expenseDate)}${e.description != null ? ' - ${e.description}' : ''}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () => context.read<ExpensesProvider>().deleteExpense(e.id!),
                  ),
                ),
              )),
        ],
      ),
    );
  }
}
