import '../db/db_helper.dart';

/// استعلامات التقارير - لا تحتفظ بحالة، تُستخدم مباشرة من شاشات التقارير
class ReportsProvider {
  Future<Map<String, double>> salesSummary(String fromDate, String toDate) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query(
      'shifts',
      where: 'shift_date BETWEEN ? AND ?',
      whereArgs: [fromDate, toDate],
    );
    double cash = 0, visa = 0, companies = 0, other = 0;
    for (final r in rows) {
      cash += (r['cash_sales'] as num).toDouble();
      visa += (r['visa_sales'] as num).toDouble();
      companies += (r['companies_sales'] as num).toDouble();
      other += (r['other_sales'] as num).toDouble();
    }
    return {
      'cash': cash,
      'visa': visa,
      'companies': companies,
      'other': other,
      'total': cash + visa + companies + other,
    };
  }

  Future<double> expensesTotal(String fromDate, String toDate) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('expenses', where: 'expense_date BETWEEN ? AND ?', whereArgs: [fromDate, toDate]);
    return rows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());
  }

  Future<double> collectionsTotal(String fromDate, String toDate) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('collections', where: 'collection_date BETWEEN ? AND ?', whereArgs: [fromDate, toDate]);
    return rows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());
  }

  /// كشف حساب شركة: كل الفواتير والمطالبات والتحصيلات
  Future<Map<String, dynamic>> companyStatement(int companyId) async {
    final db = await DBHelper.instance.database;
    final invoices = await db.query('company_invoices', where: 'company_id = ?', whereArgs: [companyId], orderBy: 'invoice_date ASC');
    final claims = await db.query('monthly_claims', where: 'company_id = ?', whereArgs: [companyId], orderBy: 'claim_month ASC');
    final claimIds = claims.map((c) => c['id']).toList();
    List<Map<String, Object?>> collections = [];
    if (claimIds.isNotEmpty) {
      final placeholders = List.filled(claimIds.length, '?').join(',');
      collections = await db.rawQuery(
        'SELECT * FROM collections WHERE claim_id IN ($placeholders) ORDER BY collection_date ASC',
        claimIds,
      );
    }
    return {'invoices': invoices, 'claims': claims, 'collections': collections};
  }

  Future<double> expensesByCategory(String fromDate, String toDate, String category) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query(
      'expenses',
      where: 'expense_date BETWEEN ? AND ? AND category = ?',
      whereArgs: [fromDate, toDate, category],
    );
    return rows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());
  }

  Future<List<Map<String, Object?>>> expenseCategoriesBreakdown(String fromDate, String toDate) async {
    final db = await DBHelper.instance.database;
    return db.rawQuery(
      '''SELECT category, SUM(amount) as total FROM expenses
         WHERE expense_date BETWEEN ? AND ?
         GROUP BY category ORDER BY total DESC''',
      [fromDate, toDate],
    );
  }
}
