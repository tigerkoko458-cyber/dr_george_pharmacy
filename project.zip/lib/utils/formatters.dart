import 'package:intl/intl.dart';

class Formatters {
  static final _currency = NumberFormat('#,##0.00', 'en_US');
  static final _dateFmt = DateFormat('yyyy-MM-dd');
  static final _monthFmt = DateFormat('yyyy-MM');
  static final _displayDateFmt = DateFormat('yyyy/MM/dd');

  static String money(double value) => '${_currency.format(value)} ج.م';

  static String date(DateTime d) => _dateFmt.format(d);
  static String month(DateTime d) => _monthFmt.format(d);
  static String displayDate(String isoDate) {
    try {
      return _displayDateFmt.format(DateTime.parse(isoDate));
    } catch (_) {
      return isoDate;
    }
  }

  static String today() => date(DateTime.now());
  static String currentMonth() => month(DateTime.now());
}
