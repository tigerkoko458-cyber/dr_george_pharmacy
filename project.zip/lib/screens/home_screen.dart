import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../utils/app_theme.dart';
import 'login_screen.dart';
import 'sales_shifts_screen.dart';
import 'companies_screen.dart';
import 'claims_screen.dart';
import 'collections_screen.dart';
import 'treasury_screen.dart';
import 'outstanding_screen.dart';
import 'expenses_screen.dart';
import 'reports_screen.dart';
import 'users_screen.dart';
import 'day_closing_screen.dart';
import 'backup_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser;

    final tiles = <_MenuTile>[
      _MenuTile('المبيعات (الشيفتات)', Icons.point_of_sale, const SalesShiftsScreen(), true),
      _MenuTile('الشركات', Icons.business, const CompaniesScreen(), auth.hasPermission('manage_companies')),
      _MenuTile('المطالبات الشهرية', Icons.receipt_long, const ClaimsScreen(), true),
      _MenuTile('التحصيلات', Icons.payments, const CollectionsScreen(), true),
      _MenuTile('الخزينة', Icons.account_balance_wallet, const TreasuryScreen(), auth.hasPermission('view_treasury')),
      _MenuTile('المبالغ غير المحصلة', Icons.warning_amber, const OutstandingScreen(), true),
      _MenuTile('المصروفات', Icons.money_off, const ExpensesScreen(), auth.hasPermission('manage_expenses')),
      _MenuTile('التقارير', Icons.bar_chart, const ReportsScreen(), auth.hasPermission('view_reports')),
      _MenuTile('إقفال اليوم', Icons.lock_clock, const DayClosingScreen(), auth.hasPermission('close_day')),
      _MenuTile('المستخدمون والصلاحيات', Icons.admin_panel_settings, const UsersScreen(), auth.hasPermission('manage_users')),
      _MenuTile('نسخ احتياطي', Icons.backup, const BackupScreen(), true),
    ].where((t) => t.visible).toList();

    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/images/logo.png', height: 34),
            const SizedBox(width: 10),
            const Text('صيدلية د/ جورج مجدي'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'تسجيل الخروج',
            onPressed: () {
              auth.logout();
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginScreen()),
                (route) => false,
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            color: AppColors.navy,
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Text(
              'مرحبًا ${user?.fullName ?? ''}',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 14),
            ),
          ),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(16),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 14,
                crossAxisSpacing: 14,
                childAspectRatio: 1.05,
              ),
              itemCount: tiles.length,
              itemBuilder: (context, i) {
                final t = tiles[i];
                return Card(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => t.screen)),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(t.icon, size: 40, color: AppColors.green),
                          const SizedBox(height: 10),
                          Text(t.title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuTile {
  final String title;
  final IconData icon;
  final Widget screen;
  final bool visible;
  _MenuTile(this.title, this.icon, this.screen, this.visible);
}
