import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/claims_provider.dart';
import '../providers/companies_provider.dart';
import '../models/monthly_claim.dart';
import '../utils/formatters.dart';
import '../utils/pdf_exporter.dart';

class OutstandingScreen extends StatefulWidget {
  const OutstandingScreen({super.key});

  @override
  State<OutstandingScreen> createState() => _OutstandingScreenState();
}

class _OutstandingScreenState extends State<OutstandingScreen> {
  List<Map<String, dynamic>> _data = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    await context.read<CompaniesProvider>().loadCompanies();
    final data = await context.read<ClaimsProvider>().outstandingClaims();
    setState(() {
      _data = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final companiesProvider = context.read<CompaniesProvider>();
    final totalRemaining = _data.fold<double>(0, (s, e) => s + (e['remaining'] as double));

    return Scaffold(
      appBar: AppBar(
        title: const Text('المبالغ غير المحصلة'),
        actions: [
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: _data.isEmpty
                ? null
                : () async {
                    final rows = _data.map((e) {
                      final claim = e['claim'] as MonthlyClaim;
                      final company = companiesProvider.byId(claim.companyId);
                      return [
                        company?.companyName ?? '',
                        claim.claimMonth,
                        Formatters.money(claim.netAmount),
                        Formatters.money(e['collected'] as double),
                        Formatters.money(e['remaining'] as double),
                      ];
                    }).toList();
                    final bytes = await PdfExporter.buildTableReport(
                      title: 'تقرير المبالغ غير المحصلة',
                      headers: ['الشركة', 'الشهر', 'صافي المطالبة', 'المحصّل', 'المتبقي'],
                      rows: rows,
                      footerNote: 'إجمالي المتبقي: ${Formatters.money(totalRemaining)}',
                    );
                    await PdfExporter.printOrShare(bytes, 'المبالغ_غير_المحصلة.pdf');
                  },
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _data.isEmpty
              ? const Center(child: Text('لا توجد مبالغ غير محصلة 🎉'))
              : Column(
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      color: Colors.red.shade50,
                      child: Text(
                        'إجمالي المتبقي: ${Formatters.money(totalRemaining)}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.red),
                      ),
                    ),
                    Expanded(
                      child: ListView.separated(
                        padding: const EdgeInsets.all(12),
                        itemCount: _data.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (context, i) {
                          final claim = _data[i]['claim'] as MonthlyClaim;
                          final collected = _data[i]['collected'] as double;
                          final remaining = _data[i]['remaining'] as double;
                          final company = companiesProvider.byId(claim.companyId);
                          return Card(
                            child: ListTile(
                              title: Text('${company?.companyName ?? ''} - ${claim.claimMonth}'),
                              subtitle: Text('صافي المطالبة: ${Formatters.money(claim.netAmount)} | تم تحصيل: ${Formatters.money(collected)}'),
                              trailing: Text(Formatters.money(remaining), style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.red)),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
    );
  }
}
