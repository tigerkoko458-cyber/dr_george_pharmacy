import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/treasury_movement.dart';

class TreasuryProvider extends ChangeNotifier {
  List<TreasuryMovement> _movements = [];
  List<TreasuryMovement> get movements => _movements;

  double _currentBalance = 0;
  double get currentBalance => _currentBalance;

  Future<double> _lastBalance() async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('treasury_movements', orderBy: 'id DESC', limit: 1);
    if (rows.isEmpty) return 0;
    return (rows.first['balance_after'] as num?)?.toDouble() ?? 0;
  }

  Future<void> recordMovement({
    required String date,
    required String type, // in | out
    required String source,
    int? referenceId,
    required double amount,
    String? description,
    int? userId,
  }) async {
    final db = await DBHelper.instance.database;
    final last = await _lastBalance();
    final newBalance = type == 'in' ? last + amount : last - amount;

    final movement = TreasuryMovement(
      movementDate: date,
      movementType: type,
      source: source,
      referenceId: referenceId,
      amount: amount,
      balanceAfter: newBalance,
      description: description,
      userId: userId,
      createdAt: DateTime.now().toIso8601String(),
    );
    await db.insert('treasury_movements', movement.toMap());
    _currentBalance = newBalance;
    notifyListeners();
  }

  Future<void> loadMovements({String? fromDate, String? toDate}) async {
    final db = await DBHelper.instance.database;
    String? where;
    List<Object?>? args;
    if (fromDate != null && toDate != null) {
      where = 'movement_date BETWEEN ? AND ?';
      args = [fromDate, toDate];
    }
    final rows = await db.query('treasury_movements', where: where, whereArgs: args, orderBy: 'id ASC');
    _movements = rows.map((e) => TreasuryMovement.fromMap(e)).toList();
    _currentBalance = await _lastBalance();
    notifyListeners();
  }

  Future<void> refreshBalance() async {
    _currentBalance = await _lastBalance();
    notifyListeners();
  }
}
