import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/claims_provider.dart';
import '../providers/companies_provider.dart';
import '../models/company_invoice.dart';
import '../utils/formatters.dart';
import '../utils/pdf_exporter.dart';

class ClaimsScreen extends StatefulWidget {
  const ClaimsScreen({super.key});

  @override
  State<ClaimsScreen> createState() => _ClaimsScreenState();
}

class _ClaimsScreenState extends State<ClaimsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CompaniesProvider>().loadCompanies();
      context.read<ClaimsProvider>().loadClaims();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المطالبات الشهرية'),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [Tab(text: 'إضافة فاتورة شركة'), Tab(text: 'المطالبات')],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: const [_AddInvoiceTab(), _ClaimsListTab()],
      ),
    );
  }
}

class _AddInvoiceTab extends StatefulWidget {
  const _AddInvoiceTab();

  @override
  State<_AddInvoiceTab> createState() => _AddInvoiceTabState();
}

class _AddInvoiceTabState extends State<_AddInvoiceTab> {
  int? _companyId;
  final _amountCtrl = TextEditingController();
  final _invoiceNoCtrl = TextEditingController();
  String _date = Formatters.today();

  @override
  Widget build(BuildContext context) {
    final companies = context.watch<CompaniesProvider>().activeCompanies;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          DropdownButtonFormField<int>(
            value: _companyId,
            decoration: const InputDecoration(labelText: 'الشركة'),
            items: companies.map((c) => DropdownMenuItem(value: c.id, child: Text('${c.companyName} (${c.companyCode})'))).toList(),
            onChanged: (v) => setState(() => _companyId = v),
          ),
          const SizedBox(height: 12),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('تاريخ الفاتورة: ${Formatters.displayDate(_date)}'),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_date), firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => _date = Formatters.date(picked));
            },
          ),
          const SizedBox(height: 8),
          TextField(controller: _invoiceNoCtrl, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'رقم الفاتورة (اختياري)')),
          const SizedBox(height: 12),
          TextField(
            controller: _amountCtrl,
            textAlign: TextAlign.right,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'قيمة الفاتورة'),
          ),
          const SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              final amount = double.tryParse(_amountCtrl.text.trim());
              if (_companyId == null || amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى اختيار الشركة وإدخال قيمة صحيحة')));
                return;
              }
              final invoice = CompanyInvoice(
                companyId: _companyId!,
                invoiceNumber: _invoiceNoCtrl.text.trim().isEmpty ? null : _invoiceNoCtrl.text.trim(),
                invoiceDate: _date,
                amount: amount,
                createdAt: DateTime.now().toIso8601String(),
              );
              await context.read<ClaimsProvider>().addInvoice(invoice);
              _amountCtrl.clear();
              _invoiceNoCtrl.clear();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل فاتورة الشركة بنجاح')));
              }
            },
            child: const Text('حفظ الفاتورة'),
          ),
        ],
      ),
    );
  }
}

class _ClaimsListTab extends StatefulWidget {
  const _ClaimsListTab();

  @override
  State<_ClaimsListTab> createState() => _ClaimsListTabState();
}

class _ClaimsListTabState extends State<_ClaimsListTab> {
  int? _companyId;
  String _month = Formatters.currentMonth();

  Future<void> _generate() async {
    if (_companyId == null) return;
    final company = context.read<CompaniesProvider>().byId(_companyId!);
    if (company == null) return;
    final claim = await context.read<ClaimsProvider>().generateOrUpdateClaim(_companyId!, _month, company.discountPercent);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم إنشاء/تحديث المطالبة - الصافي: ${Formatters.money(claim.netAmount)}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final companies = context.watch<CompaniesProvider>().activeCompanies;
    final claims = context.watch<ClaimsProvider>().claims;
    final companiesProvider = context.read<CompaniesProvider>();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            children: [
              DropdownButtonFormField<int>(
                value: _companyId,
                decoration: const InputDecoration(labelText: 'اختر الشركة لإنشاء/تحديث المطالبة'),
                items: companies.map((c) => DropdownMenuItem(value: c.id, child: Text(c.companyName))).toList(),
                onChanged: (v) => setState(() => _companyId = v),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: Text('الشهر: $_month')),
                  TextButton(
                    onPressed: () async {
                      final picked = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(2020),
                        lastDate: DateTime(2100),
                      );
                      if (picked != null) setState(() => _month = Formatters.month(picked));
                    },
                    child: const Text('تغيير'),
                  ),
                  ElevatedButton(onPressed: _generate, child: const Text('إنشاء / تحديث المطالبة')),
                ],
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: claims.isEmpty
              ? const Center(child: Text('لا يوجد مطالبات بعد'))
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: claims.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) {
                    final claim = claims[i];
                    final company = companiesProvider.byId(claim.companyId);
                    return Card(
                      child: ListTile(
                        title: Text('${company?.companyName ?? ''} - ${claim.claimMonth}'),
                        subtitle: Text(
                          'الإجمالي: ${Formatters.money(claim.totalAmount)} | الخصم: ${Formatters.money(claim.discountAmount)} | الصافي: ${Formatters.money(claim.netAmount)}\nالحالة: ${_statusLabel(claim.status)}',
                        ),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) async {
                            if (value == 'submit') {
                              await context.read<ClaimsProvider>().markSubmitted(claim.id!);
                            } else if (value == 'pdf') {
                              final bytes = await PdfExporter.buildTableReport(
                                title: 'مطالبة شهرية - ${company?.companyName ?? ''} - ${claim.claimMonth}',
                                headers: ['البيان', 'القيمة'],
                                rows: [
                                  ['إجمالي المبيعات', Formatters.money(claim.totalAmount)],
                                  ['قيمة الخصم', Formatters.money(claim.discountAmount)],
                                  ['الصافي المستحق', Formatters.money(claim.netAmount)],
                                  ['الحالة', _statusLabel(claim.status)],
                                ],
                              );
                              await PdfExporter.printOrShare(bytes, 'مطالبة_${claim.claimMonth}.pdf');
                            }
                          },
                          itemBuilder: (_) => [
                            if (claim.status == 'open') const PopupMenuItem(value: 'submit', child: Text('تحويل لحالة مُرسلة')),
                            const PopupMenuItem(value: 'pdf', child: Text('طباعة PDF')),
                          ],
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }

  String _statusLabel(String status) {
    switch (status) {
      case 'open':
        return 'مفتوحة';
      case 'submitted':
        return 'تم إرسالها للشركة';
      case 'collected':
        return 'تم التحصيل بالكامل';
      case 'partially_collected':
        return 'تحصيل جزئي';
      default:
        return status;
    }
  }
}
