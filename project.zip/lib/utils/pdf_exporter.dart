import 'dart:typed_data';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

/// تصدير التقارير إلى PDF بدعم اللغة العربية واتجاه RTL مع شعار الصيدلية
///
/// ملاحظة: الخط العربي (Noto Naskh Arabic) يتم تحميله عبر PdfGoogleFonts في
/// أول استخدام، وهذا يتطلب اتصال إنترنت متاح على جهاز المستخدم وقت التصدير.
/// بعد أول تحميل يقوم بالتخزين المؤقت (cache) محليًا وتعمل لاحقًا دون إنترنت.
class PdfExporter {
  static pw.Font? _arabicFont;
  static pw.Font? _arabicFontBold;
  static Uint8List? _logoBytes;

  static Future<void> _ensureAssets() async {
    _arabicFont ??= await PdfGoogleFonts.notoNaskhArabicRegular();
    _arabicFontBold ??= await PdfGoogleFonts.notoNaskhArabicBold();
    _logoBytes ??= (await rootBundle.load('assets/images/logo.png')).buffer.asUint8List();
  }

  static Future<pw.Widget> _buildHeader(String title) async {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.center,
      children: [
        pw.Image(pw.MemoryImage(_logoBytes!), height: 70),
        pw.SizedBox(height: 8),
        pw.Text(
          title,
          style: pw.TextStyle(font: _arabicFontBold, fontSize: 18),
          textDirection: pw.TextDirection.rtl,
        ),
        pw.Divider(thickness: 1.2),
      ],
    );
  }

  /// تقرير جدولي عام (مبيعات / مصروفات / تحصيلات / كشف حساب)
  static Future<Uint8List> buildTableReport({
    required String title,
    required List<String> headers,
    required List<List<String>> rows,
    String? footerNote,
  }) async {
    await _ensureAssets();
    final doc2 = pw.Document();
    final header = await _buildHeader(title);

    doc2.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        header: (context) => context.pageNumber == 1 ? header : pw.SizedBox(),
        build: (context) => [
          pw.TableHelper.fromTextArray(
            headers: headers,
            data: rows,
            headerStyle: pw.TextStyle(font: _arabicFontBold, fontSize: 11, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColor.fromInt(0xFF1B2A5B)),
            cellStyle: pw.TextStyle(font: _arabicFont, fontSize: 10),
            cellAlignment: pw.Alignment.centerRight,
            headerAlignment: pw.Alignment.center,
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
          ),
          if (footerNote != null) ...[
            pw.SizedBox(height: 16),
            pw.Text(footerNote, style: pw.TextStyle(font: _arabicFontBold, fontSize: 12), textDirection: pw.TextDirection.rtl),
          ],
        ],
      ),
    );

    return doc2.save();
  }

  static Future<void> printOrShare(Uint8List bytes, String fileName) async {
    await Printing.sharePdf(bytes: bytes, filename: fileName);
  }

  static Future<void> printDocument(Uint8List bytes) async {
    await Printing.layoutPdf(onLayout: (format) async => bytes);
  }
}
