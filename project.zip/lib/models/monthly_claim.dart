class MonthlyClaim {
  final int? id;
  final int companyId;
  final String claimMonth; // yyyy-MM
  final double totalAmount;
  final double discountAmount;
  final double netAmount;
  final String status; // open | submitted | collected | partially_collected
  final String? submittedAt;
  final String createdAt;

  MonthlyClaim({
    this.id,
    required this.companyId,
    required this.claimMonth,
    this.totalAmount = 0,
    this.discountAmount = 0,
    this.netAmount = 0,
    this.status = 'open',
    this.submittedAt,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'company_id': companyId,
      'claim_month': claimMonth,
      'total_amount': totalAmount,
      'discount_amount': discountAmount,
      'net_amount': netAmount,
      'status': status,
      'submitted_at': submittedAt,
      'created_at': createdAt,
    };
  }

  factory MonthlyClaim.fromMap(Map<String, dynamic> map) {
    return MonthlyClaim(
      id: map['id'] as int?,
      companyId: map['company_id'] as int,
      claimMonth: map['claim_month'] as String,
      totalAmount: (map['total_amount'] as num).toDouble(),
      discountAmount: (map['discount_amount'] as num).toDouble(),
      netAmount: (map['net_amount'] as num).toDouble(),
      status: map['status'] as String,
      submittedAt: map['submitted_at'] as String?,
      createdAt: map['created_at'] as String,
    );
  }
}
