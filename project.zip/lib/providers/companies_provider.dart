import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/company.dart';

class CompaniesProvider extends ChangeNotifier {
  List<Company> _companies = [];
  List<Company> get companies => _companies;
  List<Company> get activeCompanies => _companies.where((c) => c.isActive).toList();

  Future<void> loadCompanies() async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('companies', orderBy: 'company_code ASC');
    _companies = rows.map((e) => Company.fromMap(e)).toList();
    notifyListeners();
  }

  Future<String?> addCompany(Company company) async {
    final db = await DBHelper.instance.database;
    final existing = await db.query('companies', where: 'company_code = ?', whereArgs: [company.companyCode]);
    if (existing.isNotEmpty) return 'كود الشركة مستخدم بالفعل';
    await db.insert('companies', company.toMap());
    await loadCompanies();
    return null;
  }

  Future<void> updateCompany(Company company) async {
    final db = await DBHelper.instance.database;
    await db.update('companies', company.toMap(), where: 'id = ?', whereArgs: [company.id]);
    await loadCompanies();
  }

  Future<void> setActive(int companyId, bool isActive) async {
    final db = await DBHelper.instance.database;
    await db.update('companies', {'is_active': isActive ? 1 : 0}, where: 'id = ?', whereArgs: [companyId]);
    await loadCompanies();
  }

  Company? byId(int id) {
    try {
      return _companies.firstWhere((c) => c.id == id);
    } catch (_) {
      return null;
    }
  }
}
