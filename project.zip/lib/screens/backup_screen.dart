import 'package:flutter/material.dart';
import '../utils/backup_helper.dart';
import '../utils/app_theme.dart';

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});

  @override
  State<BackupScreen> createState() => _BackupScreenState();
}

class _BackupScreenState extends State<BackupScreen> {
  bool _busy = false;

  Future<void> _backup() async {
    setState(() => _busy = true);
    try {
      final file = await BackupHelper.createBackup();
      await BackupHelper.shareBackup(file);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إنشاء النسخة الاحتياطية بنجاح')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حدث خطأ أثناء النسخ الاحتياطي: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تحذير هام'),
        content: const Text(
          'استعادة نسخة احتياطية ستستبدل جميع البيانات الحالية بالكامل ولا يمكن التراجع عن ذلك. هل أنت متأكد من المتابعة؟',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _busy = true);
    try {
      final success = await BackupHelper.pickAndRestore();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(success ? 'تم استرجاع النسخة الاحتياطية بنجاح. يرجى إعادة تشغيل التطبيق' : 'لم يتم اختيار ملف')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('حدث خطأ أثناء الاسترجاع: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('نسخ احتياطي واسترجاع')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.backup, size: 64, color: AppColors.green),
            const SizedBox(height: 12),
            const Text(
              'يمكنك أخذ نسخة احتياطية من قاعدة بيانات الصيدلية بالكامل ومشاركتها أو حفظها، أو استعادة نسخة سابقة عند الحاجة.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              icon: const Icon(Icons.cloud_upload),
              label: const Text('إنشاء نسخة احتياطية الآن'),
              onPressed: _busy ? null : _backup,
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              icon: const Icon(Icons.settings_backup_restore),
              label: const Text('استعادة نسخة احتياطية'),
              onPressed: _busy ? null : _restore,
            ),
            if (_busy) const Padding(padding: EdgeInsets.only(top: 20), child: Center(child: CircularProgressIndicator())),
          ],
        ),
      ),
    );
  }
}
