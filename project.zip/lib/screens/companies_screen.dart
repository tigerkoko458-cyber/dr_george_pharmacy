import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/companies_provider.dart';
import '../models/company.dart';

class CompaniesScreen extends StatefulWidget {
  const CompaniesScreen({super.key});

  @override
  State<CompaniesScreen> createState() => _CompaniesScreenState();
}

class _CompaniesScreenState extends State<CompaniesScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<CompaniesProvider>().loadCompanies());
  }

  void _showForm({Company? company}) {
    final codeCtrl = TextEditingController(text: company?.companyCode ?? '');
    final nameCtrl = TextEditingController(text: company?.companyName ?? '');
    final contactCtrl = TextEditingController(text: company?.contactPerson ?? '');
    final phoneCtrl = TextEditingController(text: company?.phone ?? '');
    final addressCtrl = TextEditingController(text: company?.address ?? '');
    final discountCtrl = TextEditingController(text: company?.discountPercent.toString() ?? '0');
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
          left: 16,
          right: 16,
          top: 16,
        ),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(company == null ? 'إضافة شركة جديدة' : 'تعديل بيانات الشركة', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 12),
                TextFormField(
                  controller: codeCtrl,
                  textAlign: TextAlign.right,
                  enabled: company == null, // الكود ثابت لا يتغير بعد الإنشاء
                  decoration: const InputDecoration(labelText: 'كود الشركة (ثابت)'),
                  validator: (v) => (v == null || v.isEmpty) ? 'أدخل كود الشركة' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: nameCtrl,
                  textAlign: TextAlign.right,
                  decoration: const InputDecoration(labelText: 'اسم الشركة'),
                  validator: (v) => (v == null || v.isEmpty) ? 'أدخل اسم الشركة' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(controller: contactCtrl, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'مسؤول التواصل')),
                const SizedBox(height: 10),
                TextFormField(controller: phoneCtrl, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
                const SizedBox(height: 10),
                TextFormField(controller: addressCtrl, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'العنوان')),
                const SizedBox(height: 10),
                TextFormField(
                  controller: discountCtrl,
                  textAlign: TextAlign.right,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(labelText: 'نسبة الخصم %'),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    if (!formKey.currentState!.validate()) return;
                    final provider = context.read<CompaniesProvider>();
                    if (company == null) {
                      final newCompany = Company(
                        companyCode: codeCtrl.text.trim(),
                        companyName: nameCtrl.text.trim(),
                        contactPerson: contactCtrl.text.trim(),
                        phone: phoneCtrl.text.trim(),
                        address: addressCtrl.text.trim(),
                        discountPercent: double.tryParse(discountCtrl.text) ?? 0,
                        createdAt: DateTime.now().toIso8601String(),
                      );
                      final error = await provider.addCompany(newCompany);
                      if (ctx.mounted) {
                        Navigator.pop(ctx);
                        if (error != null) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
                        }
                      }
                    } else {
                      final updated = Company(
                        id: company.id,
                        companyCode: company.companyCode,
                        companyName: nameCtrl.text.trim(),
                        contactPerson: contactCtrl.text.trim(),
                        phone: phoneCtrl.text.trim(),
                        address: addressCtrl.text.trim(),
                        discountPercent: double.tryParse(discountCtrl.text) ?? 0,
                        isActive: company.isActive,
                        createdAt: company.createdAt,
                      );
                      await provider.updateCompany(updated);
                      if (ctx.mounted) Navigator.pop(ctx);
                    }
                  },
                  child: const Text('حفظ'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final companies = context.watch<CompaniesProvider>().companies;
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الشركات')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showForm(),
        child: const Icon(Icons.add),
      ),
      body: companies.isEmpty
          ? const Center(child: Text('لا يوجد شركات مضافة بعد'))
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: companies.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, i) {
                final c = companies[i];
                return Card(
                  child: ListTile(
                    title: Text('${c.companyName} (${c.companyCode})', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('خصم: ${c.discountPercent}%${c.phone != null && c.phone!.isNotEmpty ? ' - ${c.phone}' : ''}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Switch(
                          value: c.isActive,
                          onChanged: (v) => context.read<CompaniesProvider>().setActive(c.id!, v),
                        ),
                        IconButton(icon: const Icon(Icons.edit), onPressed: () => _showForm(company: c)),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
