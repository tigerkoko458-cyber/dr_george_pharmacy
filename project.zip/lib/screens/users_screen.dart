import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/users_provider.dart';
import '../models/user.dart';

class UsersScreen extends StatefulWidget {
  const UsersScreen({super.key});

  @override
  State<UsersScreen> createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<UsersProvider>().loadUsers());
  }

  void _showAddUserForm() {
    final usernameCtrl = TextEditingController();
    final passwordCtrl = TextEditingController();
    final fullNameCtrl = TextEditingController();
    String role = 'employee';
    final permissions = <String, bool>{
      'manage_companies': false,
      'manage_expenses': false,
      'view_treasury': false,
      'close_day': false,
      'view_reports': false,
      'manage_users': false,
    };
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom + 16, left: 16, right: 16, top: 16),
          child: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('إضافة مستخدم جديد', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: fullNameCtrl,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(labelText: 'الاسم الكامل'),
                    validator: (v) => (v == null || v.isEmpty) ? 'أدخل الاسم' : null,
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: usernameCtrl,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(labelText: 'اسم المستخدم'),
                    validator: (v) => (v == null || v.isEmpty) ? 'أدخل اسم المستخدم' : null,
                  ),
                  const SizedBox(height: 10),
                  TextFormField(
                    controller: passwordCtrl,
                    obscureText: true,
                    textAlign: TextAlign.right,
                    decoration: const InputDecoration(labelText: 'كلمة المرور'),
                    validator: (v) => (v == null || v.length < 4) ? 'كلمة المرور 4 أحرف على الأقل' : null,
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    value: role,
                    decoration: const InputDecoration(labelText: 'الدور الوظيفي'),
                    items: const [
                      DropdownMenuItem(value: 'employee', child: Text('موظف')),
                      DropdownMenuItem(value: 'manager', child: Text('مسؤول')),
                      DropdownMenuItem(value: 'admin', child: Text('مدير النظام (كل الصلاحيات)')),
                    ],
                    onChanged: (v) => setModalState(() => role = v ?? 'employee'),
                  ),
                  const SizedBox(height: 10),
                  const Align(alignment: Alignment.centerRight, child: Text('الصلاحيات الإضافية', style: TextStyle(fontWeight: FontWeight.bold))),
                  ..._permissionLabels.entries.map((entry) => CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(entry.value),
                        value: permissions[entry.key],
                        onChanged: (v) => setModalState(() => permissions[entry.key] = v ?? false),
                      )),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () async {
                      if (!formKey.currentState!.validate()) return;
                      final error = await context.read<UsersProvider>().addUser(
                            username: usernameCtrl.text.trim(),
                            password: passwordCtrl.text,
                            fullName: fullNameCtrl.text.trim(),
                            role: role,
                            permissions: permissions,
                          );
                      if (ctx.mounted) {
                        Navigator.pop(ctx);
                        if (error != null) {
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error)));
                        }
                      }
                    },
                    child: const Text('حفظ المستخدم'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static const _permissionLabels = {
    'manage_companies': 'إدارة الشركات',
    'manage_expenses': 'إدارة المصروفات',
    'view_treasury': 'عرض الخزينة',
    'close_day': 'إقفال اليوم',
    'view_reports': 'عرض التقارير',
    'manage_users': 'إدارة المستخدمين',
  };

  void _editPermissions(AppUser user) {
    final permissions = <String, bool>{
      'manage_companies': user.canManageCompanies,
      'manage_expenses': user.canManageExpenses,
      'view_treasury': user.canViewTreasury,
      'close_day': user.canCloseDay,
      'view_reports': user.canViewReports,
      'manage_users': user.canManageUsers,
    };
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) => Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom + 16, left: 16, right: 16, top: 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('صلاحيات: ${user.fullName}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              ..._permissionLabels.entries.map((entry) => CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text(entry.value),
                    value: permissions[entry.key],
                    onChanged: (v) => setModalState(() => permissions[entry.key] = v ?? false),
                  )),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: () async {
                  await context.read<UsersProvider>().updatePermissions(user.id!, permissions);
                  if (ctx.mounted) Navigator.pop(ctx);
                },
                child: const Text('حفظ الصلاحيات'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final users = context.watch<UsersProvider>().users;
    return Scaffold(
      appBar: AppBar(title: const Text('المستخدمون والصلاحيات')),
      floatingActionButton: FloatingActionButton(onPressed: _showAddUserForm, child: const Icon(Icons.person_add)),
      body: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: users.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final u = users[i];
          return Card(
            child: ListTile(
              title: Text(u.fullName, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text('${u.username} - ${_roleLabel(u.role)}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(icon: const Icon(Icons.security), tooltip: 'الصلاحيات', onPressed: () => _editPermissions(u)),
                  Switch(value: u.isActive, onChanged: (v) => context.read<UsersProvider>().updateUserStatus(u.id!, v)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  String _roleLabel(String role) {
    switch (role) {
      case 'admin':
        return 'مدير النظام';
      case 'manager':
        return 'مسؤول';
      default:
        return 'موظف';
    }
  }
}
