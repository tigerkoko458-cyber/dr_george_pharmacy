import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/collection.dart';
import 'treasury_provider.dart';

class CollectionsProvider extends ChangeNotifier {
  List<CollectionEntry> _collections = [];
  List<CollectionEntry> get collections => _collections;

  final TreasuryProvider treasuryProvider;
  CollectionsProvider(this.treasuryProvider);

  Future<void> loadForClaim(int claimId) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('collections', where: 'claim_id = ?', whereArgs: [claimId], orderBy: 'collection_date ASC');
    _collections = rows.map((e) => CollectionEntry.fromMap(e)).toList();
    notifyListeners();
  }

  Future<void> loadAll({String? fromDate, String? toDate}) async {
    final db = await DBHelper.instance.database;
    String? where;
    List<Object?>? args;
    if (fromDate != null && toDate != null) {
      where = 'collection_date BETWEEN ? AND ?';
      args = [fromDate, toDate];
    }
    final rows = await db.query('collections', where: where, whereArgs: args, orderBy: 'collection_date DESC');
    _collections = rows.map((e) => CollectionEntry.fromMap(e)).toList();
    notifyListeners();
  }

  Future<void> addCollection(CollectionEntry entry) async {
    final db = await DBHelper.instance.database;
    final id = await db.insert('collections', entry.toMap());

    await treasuryProvider.recordMovement(
      date: entry.collectionDate,
      type: 'in',
      source: 'collection',
      referenceId: id,
      amount: entry.amount,
      description: 'تحصيل من شركة',
      userId: entry.receivedBy,
    );

    // تحديث حالة المطالبة تلقائيًا
    final claimRows = await db.query('monthly_claims', where: 'id = ?', whereArgs: [entry.claimId]);
    if (claimRows.isNotEmpty) {
      final claim = claimRows.first;
      final netAmount = (claim['net_amount'] as num).toDouble();
      final collectedRows = await db.query('collections', where: 'claim_id = ?', whereArgs: [entry.claimId]);
      final totalCollected = collectedRows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());
      String newStatus;
      if (totalCollected >= netAmount - 0.001) {
        newStatus = 'collected';
      } else if (totalCollected > 0) {
        newStatus = 'partially_collected';
      } else {
        newStatus = claim['status'] as String;
      }
      await db.update('monthly_claims', {'status': newStatus}, where: 'id = ?', whereArgs: [entry.claimId]);
    }

    notifyListeners();
  }
}
