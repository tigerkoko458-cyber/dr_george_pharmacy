class TreasuryMovement {
  final int? id;
  final String movementDate;
  final String movementType; // in | out
  final String source; // shift | collection | expense | manual
  final int? referenceId;
  final double amount;
  final double? balanceAfter;
  final String? description;
  final int? userId;
  final String createdAt;

  TreasuryMovement({
    this.id,
    required this.movementDate,
    required this.movementType,
    required this.source,
    this.referenceId,
    required this.amount,
    this.balanceAfter,
    this.description,
    this.userId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'movement_date': movementDate,
      'movement_type': movementType,
      'source': source,
      'reference_id': referenceId,
      'amount': amount,
      'balance_after': balanceAfter,
      'description': description,
      'user_id': userId,
      'created_at': createdAt,
    };
  }

  factory TreasuryMovement.fromMap(Map<String, dynamic> map) {
    return TreasuryMovement(
      id: map['id'] as int?,
      movementDate: map['movement_date'] as String,
      movementType: map['movement_type'] as String,
      source: map['source'] as String,
      referenceId: map['reference_id'] as int?,
      amount: (map['amount'] as num).toDouble(),
      balanceAfter: (map['balance_after'] as num?)?.toDouble(),
      description: map['description'] as String?,
      userId: map['user_id'] as int?,
      createdAt: map['created_at'] as String,
    );
  }
}
