import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/company_invoice.dart';
import '../models/monthly_claim.dart';

/// إدارة فواتير الشركات اليومية وتجميعها في مطالبة شهرية واحدة لكل شركة
class ClaimsProvider extends ChangeNotifier {
  List<CompanyInvoice> _invoices = [];
  List<CompanyInvoice> get invoices => _invoices;

  List<MonthlyClaim> _claims = [];
  List<MonthlyClaim> get claims => _claims;

  Future<void> addInvoice(CompanyInvoice invoice) async {
    final db = await DBHelper.instance.database;
    await db.insert('company_invoices', invoice.toMap());
    notifyListeners();
  }

  Future<void> loadInvoicesForCompanyMonth(int companyId, String month) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query(
      'company_invoices',
      where: 'company_id = ? AND invoice_date LIKE ?',
      whereArgs: [companyId, '$month%'],
      orderBy: 'invoice_date ASC',
    );
    _invoices = rows.map((e) => CompanyInvoice.fromMap(e)).toList();
    notifyListeners();
  }

  Future<void> loadClaims({int? companyId, String? month}) async {
    final db = await DBHelper.instance.database;
    final conditions = <String>[];
    final args = <Object?>[];
    if (companyId != null) {
      conditions.add('company_id = ?');
      args.add(companyId);
    }
    if (month != null) {
      conditions.add('claim_month = ?');
      args.add(month);
    }
    final rows = await db.query(
      'monthly_claims',
      where: conditions.isEmpty ? null : conditions.join(' AND '),
      whereArgs: conditions.isEmpty ? null : args,
      orderBy: 'claim_month DESC',
    );
    _claims = rows.map((e) => MonthlyClaim.fromMap(e)).toList();
    notifyListeners();
  }

  /// إنشاء/إعادة حساب المطالبة الشهرية لشركة معينة (مطالبة واحدة فقط لكل شركة كل شهر)
  Future<MonthlyClaim> generateOrUpdateClaim(int companyId, String month, double discountPercent) async {
    final db = await DBHelper.instance.database;

    final invoiceRows = await db.query(
      'company_invoices',
      where: 'company_id = ? AND invoice_date LIKE ? AND claim_id IS NULL',
      whereArgs: [companyId, '$month%'],
    );
    final newTotal = invoiceRows.fold<double>(0, (sum, r) => sum + (r['amount'] as num).toDouble());

    final existingClaimRows = await db.query(
      'monthly_claims',
      where: 'company_id = ? AND claim_month = ?',
      whereArgs: [companyId, month],
    );

    MonthlyClaim claim;
    if (existingClaimRows.isNotEmpty) {
      final existing = MonthlyClaim.fromMap(existingClaimRows.first);
      final total = existing.totalAmount + newTotal;
      final discount = total * (discountPercent / 100);
      claim = MonthlyClaim(
        id: existing.id,
        companyId: companyId,
        claimMonth: month,
        totalAmount: total,
        discountAmount: discount,
        netAmount: total - discount,
        status: existing.status,
        submittedAt: existing.submittedAt,
        createdAt: existing.createdAt,
      );
      await db.update('monthly_claims', claim.toMap(), where: 'id = ?', whereArgs: [existing.id]);
    } else {
      final discount = newTotal * (discountPercent / 100);
      claim = MonthlyClaim(
        companyId: companyId,
        claimMonth: month,
        totalAmount: newTotal,
        discountAmount: discount,
        netAmount: newTotal - discount,
        status: 'open',
        createdAt: DateTime.now().toIso8601String(),
      );
      final id = await db.insert('monthly_claims', claim.toMap());
      claim = MonthlyClaim.fromMap({...claim.toMap(), 'id': id});
    }

    // ربط الفواتير الجديدة بالمطالبة
    for (final r in invoiceRows) {
      await db.update('company_invoices', {'claim_id': claim.id}, where: 'id = ?', whereArgs: [r['id']]);
    }

    await loadClaims();
    return claim;
  }

  Future<void> markSubmitted(int claimId) async {
    final db = await DBHelper.instance.database;
    await db.update(
      'monthly_claims',
      {'status': 'submitted', 'submitted_at': DateTime.now().toIso8601String()},
      where: 'id = ?',
      whereArgs: [claimId],
    );
    await loadClaims();
  }

  Future<double> totalCollectedForClaim(int claimId) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('collections', where: 'claim_id = ?', whereArgs: [claimId]);
    return rows.fold<double>(0, (sum, r) => sum + (r['amount'] as num).toDouble());
  }

  /// المبالغ غير المحصلة: كل مطالبة والمتبقي منها
  Future<List<Map<String, dynamic>>> outstandingClaims() async {
    final db = await DBHelper.instance.database;
    final claimRows = await db.query(
      'monthly_claims',
      where: "status != 'collected'",
      orderBy: 'claim_month DESC',
    );
    final result = <Map<String, dynamic>>[];
    for (final c in claimRows) {
      final claim = MonthlyClaim.fromMap(c);
      final collected = await totalCollectedForClaim(claim.id!);
      final remaining = claim.netAmount - collected;
      if (remaining > 0.001) {
        result.add({'claim': claim, 'collected': collected, 'remaining': remaining});
      }
    }
    return result;
  }
}
