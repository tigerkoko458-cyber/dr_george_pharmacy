import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/day_closing.dart';

class DayClosingProvider extends ChangeNotifier {
  List<DayClosing> _closings = [];
  List<DayClosing> get closings => _closings;

  Future<bool> isDayClosed(String date) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('day_closings', where: 'closing_date = ?', whereArgs: [date]);
    return rows.isNotEmpty;
  }

  /// إقفال اليوم: يتطلب أن تكون كل الشيفتات الثلاثة مقفولة أولًا
  Future<String?> closeDay(String date, int userId) async {
    final db = await DBHelper.instance.database;

    final already = await isDayClosed(date);
    if (already) return 'هذا اليوم مقفول بالفعل';

    final shiftRows = await db.query('shifts', where: 'shift_date = ?', whereArgs: [date]);
    if (shiftRows.length < 3) {
      return 'لا يمكن إقفال اليوم قبل تسجيل الشيفتات الثلاثة';
    }
    final anyOpen = shiftRows.any((r) => (r['is_closed'] as int) == 0);
    if (anyOpen) {
      return 'يوجد شيفت غير مقفول - يجب إقفال كل الشيفتات أولًا';
    }

    double cash = 0, visa = 0, companies = 0;
    for (final r in shiftRows) {
      cash += (r['cash_sales'] as num).toDouble();
      visa += (r['visa_sales'] as num).toDouble();
      companies += (r['companies_sales'] as num).toDouble();
    }

    final expenseRows = await db.query('expenses', where: 'expense_date = ?', whereArgs: [date]);
    final totalExpenses = expenseRows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());

    final collectionRows = await db.query('collections', where: 'collection_date = ?', whereArgs: [date]);
    final totalCollections = collectionRows.fold<double>(0, (s, r) => s + (r['amount'] as num).toDouble());

    final lastMovement = await db.query('treasury_movements', orderBy: 'id DESC', limit: 1);
    final treasuryBalance = lastMovement.isEmpty ? 0.0 : (lastMovement.first['balance_after'] as num?)?.toDouble() ?? 0.0;

    final closing = DayClosing(
      closingDate: date,
      totalCashSales: cash,
      totalVisaSales: visa,
      totalCompaniesSales: companies,
      totalExpenses: totalExpenses,
      totalCollections: totalCollections,
      treasuryBalance: treasuryBalance,
      closedBy: userId,
      createdAt: DateTime.now().toIso8601String(),
    );
    await db.insert('day_closings', closing.toMap());
    return null;
  }

  Future<void> loadClosings({String? fromDate, String? toDate}) async {
    final db = await DBHelper.instance.database;
    String? where;
    List<Object?>? args;
    if (fromDate != null && toDate != null) {
      where = 'closing_date BETWEEN ? AND ?';
      args = [fromDate, toDate];
    }
    final rows = await db.query('day_closings', where: where, whereArgs: args, orderBy: 'closing_date DESC');
    _closings = rows.map((e) => DayClosing.fromMap(e)).toList();
    notifyListeners();
  }
}
