class Company {
  final int? id;
  final String companyCode;
  final String companyName;
  final String? contactPerson;
  final String? phone;
  final String? address;
  final double discountPercent;
  final bool isActive;
  final String createdAt;

  Company({
    this.id,
    required this.companyCode,
    required this.companyName,
    this.contactPerson,
    this.phone,
    this.address,
    this.discountPercent = 0,
    this.isActive = true,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'company_code': companyCode,
      'company_name': companyName,
      'contact_person': contactPerson,
      'phone': phone,
      'address': address,
      'discount_percent': discountPercent,
      'is_active': isActive ? 1 : 0,
      'created_at': createdAt,
    };
  }

  factory Company.fromMap(Map<String, dynamic> map) {
    return Company(
      id: map['id'] as int?,
      companyCode: map['company_code'] as String,
      companyName: map['company_name'] as String,
      contactPerson: map['contact_person'] as String?,
      phone: map['phone'] as String?,
      address: map['address'] as String?,
      discountPercent: (map['discount_percent'] as num).toDouble(),
      isActive: (map['is_active'] as int) == 1,
      createdAt: map['created_at'] as String,
    );
  }
}
