import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shifts_provider.dart';
import '../providers/auth_provider.dart';
import '../models/shift.dart';
import '../utils/formatters.dart';
import '../utils/app_theme.dart';

class SalesShiftsScreen extends StatefulWidget {
  const SalesShiftsScreen({super.key});

  @override
  State<SalesShiftsScreen> createState() => _SalesShiftsScreenState();
}

class _SalesShiftsScreenState extends State<SalesShiftsScreen> {
  late String _selectedDate;

  @override
  void initState() {
    super.initState();
    _selectedDate = Formatters.today();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ShiftsProvider>().loadShiftsByDate(_selectedDate);
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.parse(_selectedDate),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() => _selectedDate = Formatters.date(picked));
      if (mounted) context.read<ShiftsProvider>().loadShiftsByDate(_selectedDate);
    }
  }

  @override
  Widget build(BuildContext context) {
    final shiftsProvider = context.watch<ShiftsProvider>();
    final existingByNumber = {for (final s in shiftsProvider.shifts) s.shiftNumber: s};

    return Scaffold(
      appBar: AppBar(title: const Text('المبيعات - الشيفتات')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(child: Text('التاريخ: ${Formatters.displayDate(_selectedDate)}', style: const TextStyle(fontWeight: FontWeight.bold))),
                TextButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), label: const Text('تغيير التاريخ')),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [1, 2, 3].map((num) {
                final shift = existingByNumber[num];
                return _ShiftCard(
                  shiftNumber: num,
                  date: _selectedDate,
                  existing: shift,
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class _ShiftCard extends StatefulWidget {
  final int shiftNumber;
  final String date;
  final Shift? existing;
  const _ShiftCard({required this.shiftNumber, required this.date, this.existing});

  @override
  State<_ShiftCard> createState() => _ShiftCardState();
}

class _ShiftCardState extends State<_ShiftCard> {
  late TextEditingController _openingCtrl;
  late TextEditingController _cashCtrl;
  late TextEditingController _visaCtrl;
  late TextEditingController _companiesCtrl;
  late TextEditingController _otherCtrl;
  late TextEditingController _notesCtrl;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    _openingCtrl = TextEditingController(text: e?.openingBalance.toString() ?? '0');
    _cashCtrl = TextEditingController(text: e?.cashSales.toString() ?? '0');
    _visaCtrl = TextEditingController(text: e?.visaSales.toString() ?? '0');
    _companiesCtrl = TextEditingController(text: e?.companiesSales.toString() ?? '0');
    _otherCtrl = TextEditingController(text: e?.otherSales.toString() ?? '0');
    _notesCtrl = TextEditingController(text: e?.notes ?? '');
  }

  @override
  void didUpdateWidget(covariant _ShiftCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.existing != widget.existing) {
      final e = widget.existing;
      _openingCtrl.text = e?.openingBalance.toString() ?? '0';
      _cashCtrl.text = e?.cashSales.toString() ?? '0';
      _visaCtrl.text = e?.visaSales.toString() ?? '0';
      _companiesCtrl.text = e?.companiesSales.toString() ?? '0';
      _otherCtrl.text = e?.otherSales.toString() ?? '0';
      _notesCtrl.text = e?.notes ?? '';
    }
  }

  double _num(TextEditingController c) => double.tryParse(c.text.trim()) ?? 0;

  Future<void> _save() async {
    final auth = context.read<AuthProvider>();
    setState(() => _saving = true);
    final shift = Shift(
      id: widget.existing?.id,
      shiftDate: widget.date,
      shiftNumber: widget.shiftNumber,
      userId: auth.currentUser!.id!,
      openingBalance: _num(_openingCtrl),
      cashSales: _num(_cashCtrl),
      visaSales: _num(_visaCtrl),
      companiesSales: _num(_companiesCtrl),
      otherSales: _num(_otherCtrl),
      notes: _notesCtrl.text.trim().isEmpty ? null : _notesCtrl.text.trim(),
      createdAt: widget.existing?.createdAt ?? DateTime.now().toIso8601String(),
    );
    final error = await context.read<ShiftsProvider>().saveShift(shift);
    setState(() => _saving = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error ?? 'تم حفظ الشيفت بنجاح')),
      );
    }
  }

  Future<void> _close() async {
    if (widget.existing == null) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد إقفال الشيفت'),
        content: const Text('لن تتمكن من تعديل بيانات الشيفت بعد إقفاله. هل تريد المتابعة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('إقفال')),
        ],
      ),
    );
    if (confirm == true) {
      await context.read<ShiftsProvider>().closeShift(widget.existing!.id!);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إقفال الشيفت وترحيل النقدية للخزينة')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isClosed = widget.existing?.isClosed ?? false;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Text('شيفت رقم ${widget.shiftNumber}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const Spacer(),
                if (isClosed)
                  const Chip(label: Text('مقفول'), backgroundColor: Colors.redAccent, labelStyle: TextStyle(color: Colors.white))
                else
                  const Chip(label: Text('مفتوح'), backgroundColor: AppColors.lightGreen),
              ],
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _field('رصيد افتتاحي', _openingCtrl, isClosed)),
              const SizedBox(width: 8),
              Expanded(child: _field('مبيعات نقدية', _cashCtrl, isClosed)),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _field('مبيعات فيزا', _visaCtrl, isClosed)),
              const SizedBox(width: 8),
              Expanded(child: _field('مبيعات شركات', _companiesCtrl, isClosed)),
            ]),
            const SizedBox(height: 8),
            _field('مبيعات أخرى', _otherCtrl, isClosed),
            const SizedBox(height: 8),
            _field('ملاحظات', _notesCtrl, isClosed, isNumber: false),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: isClosed || _saving ? null : _save,
                    child: const Text('حفظ'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: (widget.existing == null || isClosed) ? null : _close,
                    child: const Text('إقفال الشيفت'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(String label, TextEditingController ctrl, bool disabled, {bool isNumber = true}) {
    return TextField(
      controller: ctrl,
      enabled: !disabled,
      textAlign: TextAlign.right,
      keyboardType: isNumber ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
      decoration: InputDecoration(labelText: label),
    );
  }
}
