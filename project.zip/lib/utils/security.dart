import 'dart:convert';
import 'package:crypto/crypto.dart';

/// أدوات تشفير كلمات المرور (SHA-256)
class Security {
  static String hash(String plainText) {
    final bytes = utf8.encode(plainText);
    return sha256.convert(bytes).toString();
  }

  static bool verify(String plainText, String hashed) {
    return hash(plainText) == hashed;
  }
}
