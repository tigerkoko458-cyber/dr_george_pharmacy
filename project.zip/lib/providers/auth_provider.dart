import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/user.dart';
import '../utils/security.dart';

class AuthProvider extends ChangeNotifier {
  AppUser? _currentUser;
  AppUser? get currentUser => _currentUser;
  bool get isLoggedIn => _currentUser != null;

  Future<String?> login(String username, String password) async {
    final db = await DBHelper.instance.database;
    final rows = await db.query(
      'users',
      where: 'username = ? AND is_active = 1',
      whereArgs: [username],
      limit: 1,
    );
    if (rows.isEmpty) return 'اسم المستخدم غير موجود أو الحساب غير مفعّل';
    final user = AppUser.fromMap(rows.first);
    if (!Security.verify(password, user.passwordHash)) {
      return 'كلمة المرور غير صحيحة';
    }
    _currentUser = user;
    notifyListeners();
    return null; // null يعني تسجيل الدخول نجح
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }

  bool hasPermission(String permission) {
    final u = _currentUser;
    if (u == null) return false;
    if (u.role == 'admin') return true;
    switch (permission) {
      case 'manage_companies':
        return u.canManageCompanies;
      case 'manage_expenses':
        return u.canManageExpenses;
      case 'view_treasury':
        return u.canViewTreasury;
      case 'close_day':
        return u.canCloseDay;
      case 'view_reports':
        return u.canViewReports;
      case 'manage_users':
        return u.canManageUsers;
      default:
        return false;
    }
  }
}
