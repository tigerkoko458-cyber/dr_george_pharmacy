import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/user.dart';
import '../utils/security.dart';

class UsersProvider extends ChangeNotifier {
  List<AppUser> _users = [];
  List<AppUser> get users => _users;

  Future<void> loadUsers() async {
    final db = await DBHelper.instance.database;
    final rows = await db.query('users', orderBy: 'id ASC');
    _users = rows.map((e) => AppUser.fromMap(e)).toList();
    notifyListeners();
  }

  Future<String?> addUser({
    required String username,
    required String password,
    required String fullName,
    required String role,
    required Map<String, bool> permissions,
  }) async {
    final db = await DBHelper.instance.database;
    final existing = await db.query('users', where: 'username = ?', whereArgs: [username]);
    if (existing.isNotEmpty) return 'اسم المستخدم مستخدم بالفعل';

    final user = AppUser(
      username: username,
      passwordHash: Security.hash(password),
      fullName: fullName,
      role: role,
      canManageCompanies: permissions['manage_companies'] ?? false,
      canManageExpenses: permissions['manage_expenses'] ?? false,
      canViewTreasury: permissions['view_treasury'] ?? false,
      canCloseDay: permissions['close_day'] ?? false,
      canViewReports: permissions['view_reports'] ?? false,
      canManageUsers: permissions['manage_users'] ?? false,
      createdAt: DateTime.now().toIso8601String(),
    );
    await db.insert('users', user.toMap());
    await loadUsers();
    return null;
  }

  Future<void> updateUserStatus(int userId, bool isActive) async {
    final db = await DBHelper.instance.database;
    await db.update('users', {'is_active': isActive ? 1 : 0}, where: 'id = ?', whereArgs: [userId]);
    await loadUsers();
  }

  Future<void> updatePermissions(int userId, Map<String, bool> permissions) async {
    final db = await DBHelper.instance.database;
    await db.update(
      'users',
      {
        'can_manage_companies': (permissions['manage_companies'] ?? false) ? 1 : 0,
        'can_manage_expenses': (permissions['manage_expenses'] ?? false) ? 1 : 0,
        'can_view_treasury': (permissions['view_treasury'] ?? false) ? 1 : 0,
        'can_close_day': (permissions['close_day'] ?? false) ? 1 : 0,
        'can_view_reports': (permissions['view_reports'] ?? false) ? 1 : 0,
        'can_manage_users': (permissions['manage_users'] ?? false) ? 1 : 0,
      },
      where: 'id = ?',
      whereArgs: [userId],
    );
    await loadUsers();
  }

  Future<void> resetPassword(int userId, String newPassword) async {
    final db = await DBHelper.instance.database;
    await db.update('users', {'password_hash': Security.hash(newPassword)}, where: 'id = ?', whereArgs: [userId]);
  }
}
