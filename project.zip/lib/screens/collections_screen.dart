import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/claims_provider.dart';
import '../providers/companies_provider.dart';
import '../providers/collections_provider.dart';
import '../providers/auth_provider.dart';
import '../models/collection.dart';
import '../models/monthly_claim.dart';
import '../utils/formatters.dart';

class CollectionsScreen extends StatefulWidget {
  const CollectionsScreen({super.key});

  @override
  State<CollectionsScreen> createState() => _CollectionsScreenState();
}

class _CollectionsScreenState extends State<CollectionsScreen> {
  int? _companyId;
  int? _claimId;
  final _amountCtrl = TextEditingController();
  String _method = 'cash';
  String _date = Formatters.today();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<CompaniesProvider>().loadCompanies();
      context.read<ClaimsProvider>().loadClaims();
      context.read<CollectionsProvider>().loadAll();
    });
  }

  @override
  Widget build(BuildContext context) {
    final companies = context.watch<CompaniesProvider>().activeCompanies;
    final allClaims = context.watch<ClaimsProvider>().claims;
    final claimsForCompany = _companyId == null
        ? <MonthlyClaim>[]
        : allClaims.where((c) => c.companyId == _companyId).toList();
    final collections = context.watch<CollectionsProvider>().collections;
    final companiesProvider = context.read<CompaniesProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('التحصيلات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<int>(
            value: _companyId,
            decoration: const InputDecoration(labelText: 'الشركة'),
            items: companies.map((c) => DropdownMenuItem(value: c.id, child: Text(c.companyName))).toList(),
            onChanged: (v) => setState(() {
              _companyId = v;
              _claimId = null;
            }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<int>(
            value: _claimId,
            decoration: const InputDecoration(labelText: 'المطالبة الشهرية'),
            items: claimsForCompany
                .map((c) => DropdownMenuItem(value: c.id, child: Text('${c.claimMonth} - صافي ${Formatters.money(c.netAmount)}')))
                .toList(),
            onChanged: (v) => setState(() => _claimId = v),
          ),
          const SizedBox(height: 10),
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text('تاريخ التحصيل: ${Formatters.displayDate(_date)}'),
            trailing: const Icon(Icons.calendar_month),
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_date), firstDate: DateTime(2020), lastDate: DateTime(2100));
              if (picked != null) setState(() => _date = Formatters.date(picked));
            },
          ),
          TextField(
            controller: _amountCtrl,
            textAlign: TextAlign.right,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'المبلغ المحصّل'),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _method,
            decoration: const InputDecoration(labelText: 'طريقة الدفع'),
            items: const [
              DropdownMenuItem(value: 'cash', child: Text('نقدي')),
              DropdownMenuItem(value: 'transfer', child: Text('تحويل بنكي')),
              DropdownMenuItem(value: 'cheque', child: Text('شيك')),
            ],
            onChanged: (v) => setState(() => _method = v ?? 'cash'),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: () async {
              final amount = double.tryParse(_amountCtrl.text.trim());
              if (_claimId == null || _companyId == null || amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('يرجى استكمال البيانات بشكل صحيح')));
                return;
              }
              final auth = context.read<AuthProvider>();
              final entry = CollectionEntry(
                claimId: _claimId!,
                companyId: _companyId!,
                collectionDate: _date,
                amount: amount,
                paymentMethod: _method,
                receivedBy: auth.currentUser?.id,
                createdAt: DateTime.now().toIso8601String(),
              );
              await context.read<CollectionsProvider>().addCollection(entry);
              await context.read<ClaimsProvider>().loadClaims();
              _amountCtrl.clear();
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل التحصيل بنجاح')));
              }
            },
            child: const Text('تسجيل التحصيل'),
          ),
          const Divider(height: 32),
          const Text('آخر التحصيلات', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...collections.take(20).map((c) {
            final company = companiesProvider.byId(c.companyId);
            return Card(
              child: ListTile(
                title: Text('${company?.companyName ?? ''} - ${Formatters.money(c.amount)}'),
                subtitle: Text('${Formatters.displayDate(c.collectionDate)} - ${_methodLabel(c.paymentMethod)}'),
              ),
            );
          }),
        ],
      ),
    );
  }

  String _methodLabel(String m) {
    switch (m) {
      case 'cash':
        return 'نقدي';
      case 'transfer':
        return 'تحويل بنكي';
      case 'cheque':
        return 'شيك';
      default:
        return m;
    }
  }
}
