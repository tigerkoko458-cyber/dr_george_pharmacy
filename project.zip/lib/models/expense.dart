class Expense {
  final int? id;
  final String expenseDate;
  final String category;
  final String? description;
  final double amount;
  final int? userId;
  final String createdAt;

  Expense({
    this.id,
    required this.expenseDate,
    required this.category,
    this.description,
    required this.amount,
    this.userId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'expense_date': expenseDate,
      'category': category,
      'description': description,
      'amount': amount,
      'user_id': userId,
      'created_at': createdAt,
    };
  }

  factory Expense.fromMap(Map<String, dynamic> map) {
    return Expense(
      id: map['id'] as int?,
      expenseDate: map['expense_date'] as String,
      category: map['category'] as String,
      description: map['description'] as String?,
      amount: (map['amount'] as num).toDouble(),
      userId: map['user_id'] as int?,
      createdAt: map['created_at'] as String,
    );
  }
}
