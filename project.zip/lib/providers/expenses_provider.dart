import 'package:flutter/material.dart';
import '../db/db_helper.dart';
import '../models/expense.dart';
import 'treasury_provider.dart';

class ExpensesProvider extends ChangeNotifier {
  List<Expense> _expenses = [];
  List<Expense> get expenses => _expenses;

  final TreasuryProvider treasuryProvider;
  ExpensesProvider(this.treasuryProvider);

  Future<void> loadExpenses({String? fromDate, String? toDate}) async {
    final db = await DBHelper.instance.database;
    String? where;
    List<Object?>? args;
    if (fromDate != null && toDate != null) {
      where = 'expense_date BETWEEN ? AND ?';
      args = [fromDate, toDate];
    }
    final rows = await db.query('expenses', where: where, whereArgs: args, orderBy: 'id DESC');
    _expenses = rows.map((e) => Expense.fromMap(e)).toList();
    notifyListeners();
  }

  Future<void> addExpense(Expense expense) async {
    final db = await DBHelper.instance.database;
    final id = await db.insert('expenses', expense.toMap());

    await treasuryProvider.recordMovement(
      date: expense.expenseDate,
      type: 'out',
      source: 'expense',
      referenceId: id,
      amount: expense.amount,
      description: 'مصروف: ${expense.category}${expense.description != null ? ' - ${expense.description}' : ''}',
      userId: expense.userId,
    );

    await loadExpenses();
  }

  Future<void> deleteExpense(int id) async {
    final db = await DBHelper.instance.database;
    await db.delete('expenses', where: 'id = ?', whereArgs: [id]);
    await loadExpenses();
  }
}
