import 'package:flutter/material.dart';
import '../providers/reports_provider.dart';
import '../utils/formatters.dart';
import '../utils/pdf_exporter.dart';
import '../utils/excel_exporter.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final _reports = ReportsProvider();
  String _fromDate = Formatters.date(DateTime.now().subtract(const Duration(days: 30)));
  String _toDate = Formatters.today();

  Map<String, double>? _sales;
  double? _expensesTotal;
  double? _collectionsTotal;
  List<Map<String, Object?>>? _expenseBreakdown;
  bool _loading = false;

  Future<void> _runReport() async {
    setState(() => _loading = true);
    final sales = await _reports.salesSummary(_fromDate, _toDate);
    final expTotal = await _reports.expensesTotal(_fromDate, _toDate);
    final colTotal = await _reports.collectionsTotal(_fromDate, _toDate);
    final breakdown = await _reports.expenseCategoriesBreakdown(_fromDate, _toDate);
    setState(() {
      _sales = sales;
      _expensesTotal = expTotal;
      _collectionsTotal = colTotal;
      _expenseBreakdown = breakdown;
      _loading = false;
    });
  }

  List<List<String>> _tableRows() {
    if (_sales == null) return [];
    return [
      ['مبيعات نقدية', Formatters.money(_sales!['cash']!)],
      ['مبيعات فيزا', Formatters.money(_sales!['visa']!)],
      ['مبيعات شركات (آجلة)', Formatters.money(_sales!['companies']!)],
      ['مبيعات أخرى', Formatters.money(_sales!['other']!)],
      ['إجمالي المبيعات', Formatters.money(_sales!['total']!)],
      ['إجمالي المصروفات', Formatters.money(_expensesTotal ?? 0)],
      ['إجمالي التحصيلات من الشركات', Formatters.money(_collectionsTotal ?? 0)],
    ];
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _runReport());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('التقارير')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('من: ${Formatters.displayDate(_fromDate)}'),
                  onTap: () async {
                    final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_fromDate), firstDate: DateTime(2020), lastDate: DateTime(2100));
                    if (picked != null) setState(() => _fromDate = Formatters.date(picked));
                  },
                ),
              ),
              Expanded(
                child: ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('إلى: ${Formatters.displayDate(_toDate)}'),
                  onTap: () async {
                    final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_toDate), firstDate: DateTime(2020), lastDate: DateTime(2100));
                    if (picked != null) setState(() => _toDate = Formatters.date(picked));
                  },
                ),
              ),
            ],
          ),
          ElevatedButton(onPressed: _runReport, child: const Text('عرض التقرير')),
          const SizedBox(height: 16),
          if (_loading) const Center(child: CircularProgressIndicator()),
          if (!_loading && _sales != null) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: _tableRows()
                      .map((row) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [Text(row[0]), Text(row[1], style: const TextStyle(fontWeight: FontWeight.bold))],
                            ),
                          ))
                      .toList(),
                ),
              ),
            ),
            const SizedBox(height: 12),
            if (_expenseBreakdown != null && _expenseBreakdown!.isNotEmpty) ...[
              const Text('تفصيل المصروفات حسب النوع', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              ..._expenseBreakdown!.map((e) => ListTile(
                    dense: true,
                    title: Text(e['category'] as String),
                    trailing: Text(Formatters.money((e['total'] as num).toDouble())),
                  )),
            ],
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('تصدير PDF'),
                    onPressed: () async {
                      final bytes = await PdfExporter.buildTableReport(
                        title: 'تقرير مالي من ${Formatters.displayDate(_fromDate)} إلى ${Formatters.displayDate(_toDate)}',
                        headers: ['البيان', 'القيمة'],
                        rows: _tableRows(),
                      );
                      await PdfExporter.printOrShare(bytes, 'تقرير_مالي.pdf');
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.grid_on),
                    label: const Text('تصدير Excel'),
                    onPressed: () async {
                      final file = await ExcelExporter.buildTableReport(
                        title: 'تقرير مالي',
                        headers: ['البيان', 'القيمة'],
                        rows: _tableRows(),
                        fileName: 'تقرير_مالي_${_fromDate}_$_toDate',
                      );
                      await ExcelExporter.share(file);
                    },
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}
