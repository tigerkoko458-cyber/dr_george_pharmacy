import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/security.dart';

/// طبقة الاتصال بقاعدة بيانات SQLite لبرنامج صيدلية د/ جورج مجدي
/// لا يوجد إدارة أصناف أو مخزون في هذا النظام - فقط محاسبة (مبيعات / شركات / تحصيلات / خزينة / مصروفات)
class DBHelper {
  static final DBHelper instance = DBHelper._internal();
  DBHelper._internal();

  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<String> get dbPath async {
    final dir = await getApplicationDocumentsDirectory();
    return join(dir.path, 'dr_george_pharmacy.db');
  }

  Future<Database> _initDB() async {
    final path = await dbPath;
    return await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async => await db.execute('PRAGMA foreign_keys = ON'),
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    // ------------------------- المستخدمون والصلاحيات -------------------------
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        full_name TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'employee', -- 'admin' | 'manager' | 'employee'
        can_manage_companies INTEGER NOT NULL DEFAULT 0,
        can_manage_expenses INTEGER NOT NULL DEFAULT 0,
        can_view_treasury INTEGER NOT NULL DEFAULT 0,
        can_close_day INTEGER NOT NULL DEFAULT 0,
        can_view_reports INTEGER NOT NULL DEFAULT 0,
        can_manage_users INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // ------------------------- الشركات (بكود ثابت) -------------------------
    await db.execute('''
      CREATE TABLE companies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_code TEXT NOT NULL UNIQUE,
        company_name TEXT NOT NULL,
        contact_person TEXT,
        phone TEXT,
        address TEXT,
        discount_percent REAL NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
      )
    ''');

    // ------------------------- الشيفتات اليومية -------------------------
    await db.execute('''
      CREATE TABLE shifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        shift_date TEXT NOT NULL,        -- yyyy-MM-dd
        shift_number INTEGER NOT NULL,   -- 1, 2, 3
        user_id INTEGER NOT NULL,
        opening_balance REAL NOT NULL DEFAULT 0,
        cash_sales REAL NOT NULL DEFAULT 0,
        visa_sales REAL NOT NULL DEFAULT 0,
        companies_sales REAL NOT NULL DEFAULT 0, -- مبيعات آجلة على الشركات
        other_sales REAL NOT NULL DEFAULT 0,
        closing_balance REAL,
        notes TEXT,
        is_closed INTEGER NOT NULL DEFAULT 0,
        closed_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id),
        UNIQUE (shift_date, shift_number)
      )
    ''');

    // ------------------------- فواتير/مبيعات الشركات (تغذي المطالبة الشهرية) -------------------------
    await db.execute('''
      CREATE TABLE company_invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        shift_id INTEGER,
        invoice_number TEXT,
        invoice_date TEXT NOT NULL,     -- yyyy-MM-dd
        amount REAL NOT NULL,
        notes TEXT,
        claim_id INTEGER,               -- ربط بالمطالبة الشهرية بعد إصدارها
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies (id),
        FOREIGN KEY (shift_id) REFERENCES shifts (id),
        FOREIGN KEY (claim_id) REFERENCES monthly_claims (id)
      )
    ''');

    // ------------------------- المطالبات الشهرية (مطالبة واحدة لكل شركة شهريًا) -------------------------
    await db.execute('''
      CREATE TABLE monthly_claims (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_id INTEGER NOT NULL,
        claim_month TEXT NOT NULL,      -- yyyy-MM
        total_amount REAL NOT NULL DEFAULT 0,
        discount_amount REAL NOT NULL DEFAULT 0,
        net_amount REAL NOT NULL DEFAULT 0,
        status TEXT NOT NULL DEFAULT 'open', -- 'open' | 'submitted' | 'collected' | 'partially_collected'
        submitted_at TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (company_id) REFERENCES companies (id),
        UNIQUE (company_id, claim_month)
      )
    ''');

    // ------------------------- التحصيلات -------------------------
    await db.execute('''
      CREATE TABLE collections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        claim_id INTEGER NOT NULL,
        company_id INTEGER NOT NULL,
        collection_date TEXT NOT NULL,
        amount REAL NOT NULL,
        payment_method TEXT NOT NULL DEFAULT 'cash', -- 'cash' | 'transfer' | 'cheque'
        reference_no TEXT,
        received_by INTEGER,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (claim_id) REFERENCES monthly_claims (id),
        FOREIGN KEY (company_id) REFERENCES companies (id),
        FOREIGN KEY (received_by) REFERENCES users (id)
      )
    ''');

    // ------------------------- الخزينة (حركات نقدية عامة) -------------------------
    await db.execute('''
      CREATE TABLE treasury_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        movement_date TEXT NOT NULL,
        movement_type TEXT NOT NULL,   -- 'in' | 'out'
        source TEXT NOT NULL,          -- 'shift' | 'collection' | 'expense' | 'manual'
        reference_id INTEGER,          -- id شيفت/تحصيل/مصروف مرتبط
        amount REAL NOT NULL,
        balance_after REAL,
        description TEXT,
        user_id INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    ''');

    // ------------------------- المصروفات -------------------------
    await db.execute('''
      CREATE TABLE expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        expense_date TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        amount REAL NOT NULL,
        user_id INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )
    ''');

    // ------------------------- إقفال اليوم -------------------------
    await db.execute('''
      CREATE TABLE day_closings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        closing_date TEXT NOT NULL UNIQUE,
        total_cash_sales REAL NOT NULL DEFAULT 0,
        total_visa_sales REAL NOT NULL DEFAULT 0,
        total_companies_sales REAL NOT NULL DEFAULT 0,
        total_expenses REAL NOT NULL DEFAULT 0,
        total_collections REAL NOT NULL DEFAULT 0,
        treasury_balance REAL NOT NULL DEFAULT 0,
        closed_by INTEGER,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (closed_by) REFERENCES users (id)
      )
    ''');

    await _seedDefaultAdmin(db);
  }

  Future<void> _seedDefaultAdmin(Database db) async {
    // مستخدم افتراضي: admin / admin123 (يجب تغييره من داخل التطبيق)
    await db.insert('users', {
      'username': 'admin',
      'password_hash': Security.hash('admin123'),
      'full_name': 'مدير النظام',
      'role': 'admin',
      'can_manage_companies': 1,
      'can_manage_expenses': 1,
      'can_view_treasury': 1,
      'can_close_day': 1,
      'can_view_reports': 1,
      'can_manage_users': 1,
      'is_active': 1,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> closeDatabase() async {
    final db = await instance.database;
    await db.close();
    _db = null;
  }

  /// نسخ ملف قاعدة البيانات الحالي إلى مسار معين (للنسخ الاحتياطي)
  Future<File> backupTo(String destinationPath) async {
    final path = await dbPath;
    final source = File(path);
    return source.copy(destinationPath);
  }

  /// استرجاع نسخة احتياطية (استبدال قاعدة البيانات الحالية)
  Future<void> restoreFrom(String backupFilePath) async {
    await closeDatabase();
    final path = await dbPath;
    final backupFile = File(backupFilePath);
    await backupFile.copy(path);
    _db = await _initDB();
  }
}
