class DayClosing {
  final int? id;
  final String closingDate;
  final double totalCashSales;
  final double totalVisaSales;
  final double totalCompaniesSales;
  final double totalExpenses;
  final double totalCollections;
  final double treasuryBalance;
  final int? closedBy;
  final String? notes;
  final String createdAt;

  DayClosing({
    this.id,
    required this.closingDate,
    this.totalCashSales = 0,
    this.totalVisaSales = 0,
    this.totalCompaniesSales = 0,
    this.totalExpenses = 0,
    this.totalCollections = 0,
    this.treasuryBalance = 0,
    this.closedBy,
    this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'closing_date': closingDate,
      'total_cash_sales': totalCashSales,
      'total_visa_sales': totalVisaSales,
      'total_companies_sales': totalCompaniesSales,
      'total_expenses': totalExpenses,
      'total_collections': totalCollections,
      'treasury_balance': treasuryBalance,
      'closed_by': closedBy,
      'notes': notes,
      'created_at': createdAt,
    };
  }

  factory DayClosing.fromMap(Map<String, dynamic> map) {
    return DayClosing(
      id: map['id'] as int?,
      closingDate: map['closing_date'] as String,
      totalCashSales: (map['total_cash_sales'] as num).toDouble(),
      totalVisaSales: (map['total_visa_sales'] as num).toDouble(),
      totalCompaniesSales: (map['total_companies_sales'] as num).toDouble(),
      totalExpenses: (map['total_expenses'] as num).toDouble(),
      totalCollections: (map['total_collections'] as num).toDouble(),
      treasuryBalance: (map['treasury_balance'] as num).toDouble(),
      closedBy: map['closed_by'] as int?,
      notes: map['notes'] as String?,
      createdAt: map['created_at'] as String,
    );
  }
}
