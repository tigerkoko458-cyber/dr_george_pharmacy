import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/day_closing_provider.dart';
import '../providers/shifts_provider.dart';
import '../providers/auth_provider.dart';
import '../utils/formatters.dart';
import '../utils/app_theme.dart';
import '../utils/pdf_exporter.dart';

class DayClosingScreen extends StatefulWidget {
  const DayClosingScreen({super.key});

  @override
  State<DayClosingScreen> createState() => _DayClosingScreenState();
}

class _DayClosingScreenState extends State<DayClosingScreen> {
  String _date = Formatters.today();
  bool _closed = false;
  bool _loading = false;
  Map<String, double>? _shiftTotals;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _refresh());
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final closed = await context.read<DayClosingProvider>().isDayClosed(_date);
    await context.read<ShiftsProvider>().loadShiftsByDate(_date);
    final totals = await context.read<ShiftsProvider>().totalsForDate(_date);
    setState(() {
      _closed = closed;
      _shiftTotals = totals;
      _loading = false;
    });
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(context: context, initialDate: DateTime.parse(_date), firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (picked != null) {
      setState(() => _date = Formatters.date(picked));
      await _refresh();
    }
  }

  Future<void> _closeDay() async {
    final auth = context.read<AuthProvider>();
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد إقفال اليوم'),
        content: const Text('بعد إقفال اليوم لا يمكن التراجع. هل تريد المتابعة؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('إقفال اليوم')),
        ],
      ),
    );
    if (confirm != true) return;

    final error = await context.read<DayClosingProvider>().closeDay(_date, auth.currentUser!.id!);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error ?? 'تم إقفال اليوم بنجاح')));
    }
    await _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final shifts = context.watch<ShiftsProvider>().shifts;
    final allClosed = shifts.length == 3 && shifts.every((s) => s.isClosed);

    return Scaffold(
      appBar: AppBar(title: const Text('إقفال اليوم')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('التاريخ: ${Formatters.displayDate(_date)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  trailing: const Icon(Icons.calendar_month),
                  onTap: _pickDate,
                ),
                const SizedBox(height: 8),
                Card(
                  color: _closed ? Colors.green.shade50 : Colors.orange.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      children: [
                        Icon(_closed ? Icons.check_circle : Icons.info, color: _closed ? Colors.green : Colors.orange),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _closed
                                ? 'تم إقفال هذا اليوم مسبقًا'
                                : allClosed
                                    ? 'كل الشيفتات مقفولة - جاهز لإقفال اليوم'
                                    : 'يوجد شيفتات غير مقفولة (${shifts.where((s) => s.isClosed).length}/3)',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                if (_shiftTotals != null)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          _row('مبيعات نقدية', _shiftTotals!['cash']!),
                          _row('مبيعات فيزا', _shiftTotals!['visa']!),
                          _row('مبيعات شركات', _shiftTotals!['companies']!),
                          _row('مبيعات أخرى', _shiftTotals!['other']!),
                          const Divider(),
                          _row('الإجمالي', _shiftTotals!['total']!, bold: true),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 20),
                if (!_closed)
                  ElevatedButton(
                    onPressed: allClosed ? _closeDay : null,
                    child: const Text('إقفال اليوم'),
                  )
                else
                  OutlinedButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('طباعة تقرير إقفال اليوم'),
                    onPressed: () async {
                      final t = _shiftTotals!;
                      final bytes = await PdfExporter.buildTableReport(
                        title: 'تقرير إقفال يوم ${Formatters.displayDate(_date)}',
                        headers: ['البيان', 'القيمة'],
                        rows: [
                          ['مبيعات نقدية', Formatters.money(t['cash']!)],
                          ['مبيعات فيزا', Formatters.money(t['visa']!)],
                          ['مبيعات شركات', Formatters.money(t['companies']!)],
                          ['مبيعات أخرى', Formatters.money(t['other']!)],
                          ['الإجمالي', Formatters.money(t['total']!)],
                        ],
                      );
                      await PdfExporter.printOrShare(bytes, 'إقفال_يوم_$_date.pdf');
                    },
                  ),
              ],
            ),
    );
  }

  Widget _row(String label, double value, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, color: bold ? AppColors.navy : null);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [Text(label, style: style), Text(Formatters.money(value), style: style)],
      ),
    );
  }
}
