class CollectionEntry {
  final int? id;
  final int claimId;
  final int companyId;
  final String collectionDate;
  final double amount;
  final String paymentMethod; // cash | transfer | cheque
  final String? referenceNo;
  final int? receivedBy;
  final String? notes;
  final String createdAt;

  CollectionEntry({
    this.id,
    required this.claimId,
    required this.companyId,
    required this.collectionDate,
    required this.amount,
    this.paymentMethod = 'cash',
    this.referenceNo,
    this.receivedBy,
    this.notes,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'claim_id': claimId,
      'company_id': companyId,
      'collection_date': collectionDate,
      'amount': amount,
      'payment_method': paymentMethod,
      'reference_no': referenceNo,
      'received_by': receivedBy,
      'notes': notes,
      'created_at': createdAt,
    };
  }

  factory CollectionEntry.fromMap(Map<String, dynamic> map) {
    return CollectionEntry(
      id: map['id'] as int?,
      claimId: map['claim_id'] as int,
      companyId: map['company_id'] as int,
      collectionDate: map['collection_date'] as String,
      amount: (map['amount'] as num).toDouble(),
      paymentMethod: map['payment_method'] as String,
      referenceNo: map['reference_no'] as String?,
      receivedBy: map['received_by'] as int?,
      notes: map['notes'] as String?,
      createdAt: map['created_at'] as String,
    );
  }
}
