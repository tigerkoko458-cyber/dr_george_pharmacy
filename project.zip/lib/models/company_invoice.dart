class CompanyInvoice {
  final int? id;
  final int companyId;
  final int? shiftId;
  final String? invoiceNumber;
  final String invoiceDate; // yyyy-MM-dd
  final double amount;
  final String? notes;
  final int? claimId;
  final String createdAt;

  CompanyInvoice({
    this.id,
    required this.companyId,
    this.shiftId,
    this.invoiceNumber,
    required this.invoiceDate,
    required this.amount,
    this.notes,
    this.claimId,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'company_id': companyId,
      'shift_id': shiftId,
      'invoice_number': invoiceNumber,
      'invoice_date': invoiceDate,
      'amount': amount,
      'notes': notes,
      'claim_id': claimId,
      'created_at': createdAt,
    };
  }

  factory CompanyInvoice.fromMap(Map<String, dynamic> map) {
    return CompanyInvoice(
      id: map['id'] as int?,
      companyId: map['company_id'] as int,
      shiftId: map['shift_id'] as int?,
      invoiceNumber: map['invoice_number'] as String?,
      invoiceDate: map['invoice_date'] as String,
      amount: (map['amount'] as num).toDouble(),
      notes: map['notes'] as String?,
      claimId: map['claim_id'] as int?,
      createdAt: map['created_at'] as String,
    );
  }
}
